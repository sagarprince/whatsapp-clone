import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-user-form-fields-settings',
  templateUrl: './user-form-fields-settings.component.html',
  styleUrls: ['./user-form-fields-settings.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class UserFormFieldsSettingsComponent implements OnInit {    

    constructor() {
        
    }
    
    ngOnInit(): void{        
        
    }   
    
}
