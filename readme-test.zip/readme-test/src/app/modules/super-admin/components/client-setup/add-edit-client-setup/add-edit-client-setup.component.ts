import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-add-edit-client-setup',
  templateUrl: './add-edit-client-setup.component.html',
  styleUrls: ['./add-edit-client-setup.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class AddEditClientSetupComponent implements OnInit {
    
    constructor() {
        
    }
    
    ngOnInit(): void{        
        
    }   

}
