import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-email-settings',
  templateUrl: './email-settings.component.html',
  styleUrls: ['./email-settings.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class EmailSettingsComponent implements OnInit {    

    constructor() {
        
    }
    
    ngOnInit(): void{        
        
    }   
    
}
