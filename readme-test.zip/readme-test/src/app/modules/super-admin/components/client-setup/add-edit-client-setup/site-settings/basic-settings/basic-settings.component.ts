import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-basic-settings',
  templateUrl: './basic-settings.component.html',
  styleUrls: ['./basic-settings.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class BasicSettingsComponent implements OnInit {    

    constructor() {
        
    }
    
    ngOnInit(): void{        
        
    }   
    
}
