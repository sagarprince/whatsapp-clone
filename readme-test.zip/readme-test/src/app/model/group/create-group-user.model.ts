export class User{
       userId : string
}