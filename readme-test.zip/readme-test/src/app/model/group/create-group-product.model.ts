export class Product {
    productId : string
}