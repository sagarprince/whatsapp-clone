import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MdDialogRef } from '@angular/material';

@Component({
  selector: 'app-upload-list',
  templateUrl: './upload-list.component.html',
  styleUrls: ['./upload-list.component.scss']
})

export class UploadListComponent implements OnInit {

    constructor(public _dialogRef: MdDialogRef<UploadListComponent>) { 
        
    }

    ngOnInit() {

    }

    closePopup() {
      this._dialogRef.close();
    }
  
}
