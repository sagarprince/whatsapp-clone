import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';

import { MdDialog } from '@angular/material';

import { DataTableDirective } from 'angular-datatables';

import { DataTablesController } from '../../../shared/controllers/data-tables.controller';

import { SweetAlertController } from '../../../shared/controllers/sweet-alert.controller';

import { AddEditCostCenterComponent } from './add-edit-cost-center/add-edit-cost-center.component';

declare var $;

@Component({
  selector: 'app-cost-center',
  templateUrl: './cost-center.component.html',
  styleUrls: ['./cost-center.component.scss']
})

export class CostCenterComponent implements OnInit, OnDestroy {

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtOptions: any = {};

    records: Array<any> = [];    

    dtCtrl: any = null;

    dialogOptions: any = {
        width: '510px',
        height: '260px',
        panelClass: 'appModalPopup'          
    };

    constructor(public dialog: MdDialog) {        
        this.records = [
            {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-TX",
                "assign_group": "Group 4, Group 5",
                "job_counts": 9,
                "budgets": 2064,
                "redeem": 1641
            },
                {
                "cost_center_code": "BOA-TX-6234",
                "cost_center": "BOA-ND",
                "assign_group": "Group 4, Group 5",
                "job_counts": 9,
                "budgets": 3048,
                "redeem": 251
            },
                {
                "cost_center_code": "BOA-NY-1234",
                "cost_center": "BOA-ND",
                "assign_group": "Group 1",
                "job_counts": 7,
                "budgets": 2584,
                "redeem": 245
            },
                {
                "cost_center_code": "BOA-NY-1234",
                "cost_center": "BOA-GA",
                "assign_group": "Group 4, Group 5",
                "job_counts": 6,
                "budgets": 1373,
                "redeem": 1334
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-TX",
                "assign_group": "Group 1, Group 2",
                "job_counts": 4,
                "budgets": 1830,
                "redeem": 2140
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-TX",
                "assign_group": "Group 1, Group 2",
                "job_counts": 2,
                "budgets": 6283,
                "redeem": 2227
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-MT",
                "assign_group": "Group 3, Group 2",
                "job_counts": 3,
                "budgets": 3151,
                "redeem": 2925
            },
                {
                "cost_center_code": "BOA-TX-6234",
                "cost_center": "BOA-AZ",
                "assign_group": "Group 3, Group 2",
                "job_counts": 1,
                "budgets": 7891,
                "redeem": 1876
            },
                {
                "cost_center_code": "BOA-TX-6234",
                "cost_center": "BOA-ND",
                "assign_group": "Group 1",
                "job_counts": 7,
                "budgets": 824,
                "redeem": 372
            },
                {
                "cost_center_code": "BOA-LA-9234",
                "cost_center": "BOA-AZ",
                "assign_group": "Group 4, Group 5",
                "job_counts": 4,
                "budgets": 7724,
                "redeem": 1808
            },
                {
                "cost_center_code": "BOA-TX-6234",
                "cost_center": "BOA-MT",
                "assign_group": "Group 1",
                "job_counts": 2,
                "budgets": 5887,
                "redeem": 2782
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-TX",
                "assign_group": "Group 4, Group 5",
                "job_counts": 4,
                "budgets": 772,
                "redeem": 1791
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-SC",
                "assign_group": "Group 1, Group 2",
                "job_counts": 4,
                "budgets": 1497,
                "redeem": 2839
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-ND",
                "assign_group": "Group 4, Group 5",
                "job_counts": 9,
                "budgets": 3562,
                "redeem": 1509
            },
                {
                "cost_center_code": "BOA-TX-6234",
                "cost_center": "BOA-ND",
                "assign_group": "Group 1",
                "job_counts": 7,
                "budgets": 4830,
                "redeem": 276
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-PA",
                "assign_group": "Group 4, Group 5",
                "job_counts": 7,
                "budgets": 2232,
                "redeem": 2496
            },
                {
                "cost_center_code": "BOA-LA-9234",
                "cost_center": "BOA-MT",
                "assign_group": "Group 1, Group 2",
                "job_counts": 9,
                "budgets": 2841,
                "redeem": 2090
            },
                {
                "cost_center_code": "BOA-NY-1234",
                "cost_center": "BOA-LA",
                "assign_group": "Group 3, Group 2",
                "job_counts": 2,
                "budgets": 2018,
                "redeem": 1809
            },
                {
                "cost_center_code": "BOA-NY-1234",
                "cost_center": "BOA-NY",
                "assign_group": "Group 1, Group 2",
                "job_counts": 7,
                "budgets": 5268,
                "redeem": 401
            },
                {
                "cost_center_code": "BOA-TX-6234",
                "cost_center": "BOA-PA",
                "assign_group": "Group 3, Group 2",
                "job_counts": 2,
                "budgets": 3351,
                "redeem": 2666
            },
                {
                "cost_center_code": "BOA-NY-1234",
                "cost_center": "BOA-AZ",
                "assign_group": "Group 1, Group 2",
                "job_counts": 2,
                "budgets": 1458,
                "redeem": 2299
            },
                {
                "cost_center_code": "BOA-NY-1234",
                "cost_center": "BOA-SC",
                "assign_group": "Group 4, Group 5",
                "job_counts": 6,
                "budgets": 6396,
                "redeem": 2557
            },
                {
                "cost_center_code": "BOA-TX-6234",
                "cost_center": "BOA-AZ",
                "assign_group": "Group 1, Group 2",
                "job_counts": 7,
                "budgets": 1093,
                "redeem": 1802
            },
                {
                "cost_center_code": "BOA-LA-9234",
                "cost_center": "BOA-AZ",
                "assign_group": "Group 3, Group 2",
                "job_counts": 10,
                "budgets": 6970,
                "redeem": 2124
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-AZ",
                "assign_group": "Group 1",
                "job_counts": 2,
                "budgets": 4587,
                "redeem": 1207
            },
                {
                "cost_center_code": "BOA-LA-9234",
                "cost_center": "BOA-PA",
                "assign_group": "Group 3, Group 2",
                "job_counts": 4,
                "budgets": 3205,
                "redeem": 2942
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-GA",
                "assign_group": "Group 4, Group 5",
                "job_counts": 5,
                "budgets": 4844,
                "redeem": 2281
            },
                {
                "cost_center_code": "BOA-TX-6234",
                "cost_center": "BOA-GA",
                "assign_group": "Group 1",
                "job_counts": 2,
                "budgets": 4783,
                "redeem": 2181
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-NY",
                "assign_group": "Group 1, Group 2",
                "job_counts": 4,
                "budgets": 4864,
                "redeem": 1692
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-SC",
                "assign_group": "Group 1, Group 2",
                "job_counts": 2,
                "budgets": 6168,
                "redeem": 2279
            },
                {
                "cost_center_code": "BOA-NY-1234",
                "cost_center": "BOA-TX",
                "assign_group": "Group 1, Group 2",
                "job_counts": 6,
                "budgets": 457,
                "redeem": 428
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-TX",
                "assign_group": "Group 4, Group 5",
                "job_counts": 7,
                "budgets": 6352,
                "redeem": 2997
            },
                {
                "cost_center_code": "BOA-TX-6234",
                "cost_center": "BOA-AZ",
                "assign_group": "Group 3, Group 2",
                "job_counts": 10,
                "budgets": 4615,
                "redeem": 1337
            },
                {
                "cost_center_code": "BOA-NY-1234",
                "cost_center": "BOA-NY",
                "assign_group": "Group 1",
                "job_counts": 6,
                "budgets": 5113,
                "redeem": 190
            },
                {
                "cost_center_code": "BOA-LA-9234",
                "cost_center": "BOA-TX",
                "assign_group": "Group 1, Group 2",
                "job_counts": 3,
                "budgets": 1646,
                "redeem": 1661
            },
                {
                "cost_center_code": "BOA-LA-9234",
                "cost_center": "BOA-GA",
                "assign_group": "Group 3, Group 2",
                "job_counts": 1,
                "budgets": 5179,
                "redeem": 394
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-SC",
                "assign_group": "Group 4, Group 5",
                "job_counts": 9,
                "budgets": 4254,
                "redeem": 1769
            },
                {
                "cost_center_code": "BOA-LA-9234",
                "cost_center": "BOA-MT",
                "assign_group": "Group 1, Group 2",
                "job_counts": 8,
                "budgets": 7812,
                "redeem": 2911
            },
                {
                "cost_center_code": "BOA-MT-5234",
                "cost_center": "BOA-AZ",
                "assign_group": "Group 4, Group 5",
                "job_counts": 5,
                "budgets": 6605,
                "redeem": 196
            },
                {
                "cost_center_code": "BOA-NY-1234",
                "cost_center": "BOA-GA",
                "assign_group": "Group 1",
                "job_counts": 2,
                "budgets": 1057,
                "redeem": 2533
            }
        ]
    }

    ngOnInit() {
        this.dtCtrl = new DataTablesController({
            aoColumnDefs: [
                { 
                    bSortable: false,                     
                    aTargets: [6]
                }
            ]
        });
        this.dtOptions = this.dtCtrl.dataTableOptions;
        this.dtCtrl.dataTableInstanceInit(this.dtElement, (dtInstance, inputEl) => {                
            inputEl.on( 'keyup change', function () {
                let that = $(this);
                let index = that.attr('data-index');                
                dtInstance.columns(index).search(this.value).draw();
            });
        });        
    }

    addCostCenterPopup() {
        let addCostCenterDialogRef = this.dialog.open(AddEditCostCenterComponent, this.dialogOptions);
        addCostCenterDialogRef.componentInstance.heading = 'Add Cost Center';
        addCostCenterDialogRef.componentInstance.saveBtnTitle = 'Add';
    }

    editCostCenterPopup() {
        let editCostCenterDialogRef = this.dialog.open(AddEditCostCenterComponent, this.dialogOptions);
        editCostCenterDialogRef.componentInstance.heading = 'Edit Cost Center';
        editCostCenterDialogRef.componentInstance.saveBtnTitle = 'Save';
        editCostCenterDialogRef.componentInstance.setEditFormValues({
            costCenterName: 'BOY-NY',
            costCenterCode: 'BOY-NY-1234',
            budgetLimit: '1240',
            group: 2
        });
    }

    deleteCostCenter() {
        let deleteCostCenterConfirmAlert = new SweetAlertController();
        deleteCostCenterConfirmAlert.deleteConfirm({}, ()=> {
            console.log('yes');
        });
    }

    ngOnDestroy() {
        this.dtCtrl.destroy();
    }

}