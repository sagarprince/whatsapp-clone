import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { MdDialogRef } from '@angular/material';

import { MdSnackBar } from '@angular/material';

import { ToastController } from '../../../../shared/controllers/toast.controller';

@Component({
  selector: 'app-add-edit-cost-center',
  templateUrl: './add-edit-cost-center.component.html',
  styleUrls: ['./add-edit-cost-center.component.scss']
})

export class AddEditCostCenterComponent implements OnInit {

    @Input('heading') heading = 'Add Cost Center';

    @Input('saveButtonTitle') saveBtnTitle = 'Add';

    addEditCostCenterForm: FormGroup;    

    groups: Array<any> = [
        {
            id: 1,
            name: 'Group 1'
        },
        {
            id: 2,
            name: 'Group 2'
        },
        {
            id: 3,
            name: 'Group 3'
        },
        {
            id: 4,
            name: 'Group 4'
        }
    ];

    constructor(private _fb: FormBuilder, 
    public _dialogRef: MdDialogRef<AddEditCostCenterComponent>,
    public _toastCtrl: ToastController) {      

        this.addEditCostCenterForm = this._fb.group({
            costCenterName: new FormControl('', [Validators.required]),
            costCenterCode: new FormControl('', [Validators.required]),
            budgetLimit: new FormControl(''),
            group: new FormControl('')          
        });
    }
    
    ngOnInit() {        
        
    }

    saveCostCenter({value, valid}: {value: any, valid: boolean}) {
        if (!valid) {
            this.addEditCostCenterForm.markAsDirty();
        } else {
            this.addEditCostCenterForm.markAsPristine();
            this._dialogRef.close();        
            this._toastCtrl.successToast('Added Successfully !');
        }
    }

    setEditFormValues(details?: any) {        
        this.addEditCostCenterForm.patchValue(details);
    }

    closePopup() {
        this._dialogRef.close();
    }

}
