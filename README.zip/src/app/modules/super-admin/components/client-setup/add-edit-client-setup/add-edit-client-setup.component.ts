import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MdDialogRef } from '@angular/material';
import { ToastController } from '../../../../shared/controllers/toast.controller';
import { Pattern } from '../../../../../model/util/pattern.model';
import { FileUploadController } from '../../../../shared/controllers/file-uploader.controller';

@Component({
  selector: 'app-add-edit-client-setup',
  templateUrl: './add-edit-client-setup.component.html',
  styleUrls: ['./add-edit-client-setup.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class AddEditClientSetupComponent implements OnInit {

    @Input('heading') heading = 'Add Client';

    @Input('saveButtonTitle') saveBtnTitle = 'Add';

    addEditClientSetupForm: FormGroup;

    logoSelected: boolean = false;

    logoString: string = '';

    userTypes = [
        {value: 'test-1', text: 'Test 1'},
        {value: 'test-2', text: 'Test 2'},
        {value: 'test-3', text: 'Test 3'}
    ];

    skillTypes = [
        {value: 'test-1', text: 'Training'},
        {value: 'test-2', text: 'Test 2'},
        {value: 'test-3', text: 'Test 3'}
    ];

    clients = [
        {value: 'test-1', text: 'BOA1'},
        {value: 'test-2', text: 'BOA2'},
        {value: 'test-3', text: 'BOA3'}
    ];

    assignQueues = [
        {value: 'test-1', text: 'Test 1'},
        {value: 'test-2', text: 'Test 2'},
        {value: 'test-3', text: 'Test 3'}
    ];

    constructor(private _fb: FormBuilder, 
    public _dialogRef: MdDialogRef<AddEditClientSetupComponent>,
    public _toastCtrl: ToastController,
    public fileUploadCtrl: FileUploadController) {
        const EMAIL_REGEX = Pattern.emailPattern;
        const NUMBER_REGEX = Pattern.onlyNumberPattern;

        this.addEditClientSetupForm = this._fb.group({
            clientCode: new FormControl('', [Validators.required]),          
            clientName: new FormControl('', [Validators.required]),          
            address: new FormControl(''),
            city: new FormControl(''),            
            state: new FormControl(''),
            zipCode: new FormControl(''),
            primaryContact: new FormControl(''),
            phoneNumber: new FormControl(''),
            fax: new FormControl(''),
            email: new FormControl('', [Validators.required, Validators.pattern(EMAIL_REGEX)]),  
        });
    }
    
    ngOnInit(): void{        
        $('.add-edit-client-setup').closest('.cdk-overlay-pane').addClass('clientAddEditPopup');
    }

    saveClient({value, valid}: {value: any, valid: boolean}) {                
        if (!valid) {
            this.addEditClientSetupForm.markAsDirty();
        } else {
            this.addEditClientSetupForm.markAsPristine();
            this._dialogRef.close();        
            this._toastCtrl.successToast('Added Successfully !');
        }
    }

    setEditFormValues(details?: any) {        
        this.addEditClientSetupForm.patchValue(details);
    }

    selectLogo(input) {
        this.fileUploadCtrl.readImageFile(input, {width: 230, height: 80}, (dataUrl) => {
            this.logoString = dataUrl;
            this.logoSelected = true;
        });
    }

    removeLogo() {
        this.logoString = '';
        this.logoSelected = false;
    }

    closePopup() {
        this._dialogRef.close();
    }

}
