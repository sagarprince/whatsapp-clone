import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MdDialog } from '@angular/material';
import { Subject } from 'rxjs/Rx';
import { DataTableDirective } from 'angular-datatables';
import { DataTablesController } from '../../../shared/controllers/data-tables.controller';
import { SweetAlertController } from '../../../shared/controllers/sweet-alert.controller';
import { AddEditClientSetupComponent } from './add-edit-client-setup/add-edit-client-setup.component';

declare var $;

@Component({
  selector: 'app-client-setup',
  templateUrl: './client-setup.component.html',
  styleUrls: ['./client-setup.component.scss']
})

export class ClientSetupComponent implements OnInit, OnDestroy {

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtOptions: any = {};

    records: Array<any> = [];    

    dtCtrl: any = null;

    dialogOptions: any = {
        width: '800px',
        height: '550px',
        panelClass: 'appModalPopup'          
    };

    dtTrigger: Subject<any> = new Subject();

    constructor(public dialog: MdDialog, private _router: Router) {        
        
    }

    ngOnInit() {
        this.dtCtrl = new DataTablesController({
            aoColumnDefs: [
                { 
                    bSortable: false,                     
                    aTargets: [3]
                }
            ]
        });
        this.dtOptions = this.dtCtrl.dataTableOptions;        

        setTimeout(() => {
            this.records = [
                {
                    "client_code": "BA007",
                    "client_name": "Rebecca Mckay",
                    "email": "Rebec.MCKAY9154@mailinator.com"
                },
                {
                    "client_code": "BA0012",
                    "client_name": "Kevin Bullock",
                    "email": "Kevi.BUL6911@dispostable.com"
                },
                    {
                    "client_code": "BA0010",
                    "client_name": "Jasmin Burke",
                    "email": "Jasm.BURKE4519@dispostable.com"
                },
                    {
                    "client_code": "BA005",
                    "client_name": "Alan Stokes",
                    "email": "Alan.STOKE9219@monumentmail.com"
                },
                    {
                    "client_code": "BA008",
                    "client_name": "Knox Burnett",
                    "email": "Kno.BURNE5144@mailinator.com"
                },
                    {
                    "client_code": "BA0010",
                    "client_name": "Sarah Tyson",
                    "email": "Sara.TYSO6041@monumentmail.com"
                },
                    {
                    "client_code": "BA0012",
                    "client_name": "Wesley Higgins",
                    "email": "Wesl.HIGGINS8110@yopmail.com"
                },
                    {
                    "client_code": "BA008",
                    "client_name": "Marco Barr",
                    "email": "Marco.BAR7306@mailinator.com"
                },
                    {
                    "client_code": "BA002",
                    "client_name": "Aspen Jackson",
                    "email": "Asp.JAC3101@yopmail.com"
                },
                    {
                    "client_code": "BA008",
                    "client_name": "Leanna Maddox",
                    "email": "Lea.MAD3256@yopmail.com"
                },
                    {
                    "client_code": "BA002",
                    "client_name": "Giselle Stevenson",
                    "email": "Giselle.STEVENSO5427@reallymymail.com"
                },
                    {
                    "client_code": "BA0012",
                    "client_name": "Holly Conrad",
                    "email": "Holl.CONRA6569@monumentmail.com"
                },
                    {
                    "client_code": "BA005",
                    "client_name": "Lizbeth Rutledge",
                    "email": "Lizb.RUTLE3760@monumentmail.com"
                },
                    {
                    "client_code": "BA003",
                    "client_name": "Melina Little",
                    "email": "Melin.LIT5794@yopmail.com"
                },
                    {
                    "client_code": "BA0010",
                    "client_name": "Anthony Daugherty",
                    "email": "Ant.DAUG9161@dispostable.com"
                },
                    {
                    "client_code": "BA009",
                    "client_name": "Alicia Hall",
                    "email": "Alici.HAL5771@monumentmail.com"
                },
                    {
                    "client_code": "BA002",
                    "client_name": "Penelope Holloway",
                    "email": "Pene.HOLLOWAY4421@monumentmail.com"
                },
                    {
                    "client_code": "BA0012",
                    "client_name": "Chace Mathews",
                    "email": "Chace.MATHEW7330@reallymymail.com"
                },
                    {
                    "client_code": "BA006",
                    "client_name": "Juliet Young",
                    "email": "Jul.YO4570@monumentmail.com"
                },
                    {
                    "client_code": "BA009",
                    "client_name": "Liliana Silva",
                    "email": "Lil.SI9888@mailinator.com"
                },
                    {
                    "client_code": "BA005",
                    "client_name": "Gage Hanson",
                    "email": "Gag.HANSON5406@reallymymail.com"
                },
                    {
                    "client_code": "BA007",
                    "client_name": "Jillian Giles",
                    "email": "Jil.GILES6519@mailinator.com"
                },
                    {
                    "client_code": "BA006",
                    "client_name": "Chandler Mason",
                    "email": "Chand.MA8748@dispostable.com"
                },
                    {
                    "client_code": "BA008",
                    "client_name": "Alianna Rush",
                    "email": "Alian.RUS6973@monumentmail.com"
                },
                    {
                    "client_code": "BA0012",
                    "client_name": "Angie Ruiz",
                    "email": "An.RUI5551@dispostable.com"
                },
                    {
                    "client_code": "BA009",
                    "client_name": "Adalyn King",
                    "email": "Adalyn.KI1834@monumentmail.com"
                },
                    {
                    "client_code": "BA0012",
                    "client_name": "Marcel Higgins",
                    "email": "Marc.HIGG6159@reallymymail.com"
                },
                    {
                    "client_code": "BA007",
                    "client_name": "Sariyah Glass",
                    "email": "Sariyah.GLASS5081@mailinator.com"
                },
                    {
                    "client_code": "BA003",
                    "client_name": "Jeramiah Bradley",
                    "email": "Jeramiah.BRA7799@reallymymail.com"
                },
                    {
                    "client_code": "BA008",
                    "client_name": "Milana Duffy",
                    "email": "Mil.DUFF8640@monumentmail.com"
                },
                    {
                    "client_code": "BA0010",
                    "client_name": "Cecelia Maldonado",
                    "email": "Ceceli.MALDONA2894@dispostable.com"
                },
                    {
                    "client_code": "BA001",
                    "client_name": "Sariyah Mullins",
                    "email": "Sariya.MUL9328@dispostable.com"
                },
                    {
                    "client_code": "BA0012",
                    "client_name": "Addyson Pickett",
                    "email": "Addyso.PICKE5137@mailinator.com"
                },
                    {
                    "client_code": "BA0011",
                    "client_name": "Paige Vincent",
                    "email": "Paige.VIN8987@reallymymail.com"
                },
                    {
                    "client_code": "BA007",
                    "client_name": "Jamie Castro",
                    "email": "Ja.CASTR5216@dispostable.com"
                },
                    {
                    "client_code": "BA0011",
                    "client_name": "Jake Brock",
                    "email": "Ja.BROCK2553@dispostable.com"
                },
                    {
                    "client_code": "BA0010",
                    "client_name": "Rachael Wong",
                    "email": "Rach.WON9333@yopmail.com"
                },
                    {
                    "client_code": "BA007",
                    "client_name": "Julius Woodward",
                    "email": "Julius.WOODWARD3257@dispostable.com"
                },
                    {
                    "client_code": "BA009",
                    "client_name": "Bristol Colon",
                    "email": "Bri.COLO6710@monumentmail.com"
                },
                    {
                    "client_code": "BA004",
                    "client_name": "Melody Nunez",
                    "email": "Mel.NU1606@dispostable.com"
                }
            ];
            this.dtTrigger.next();
            this.dtCtrl.commonDTInit(this.dtElement);
        }, 1000);
    }

    addClientPopup() {
        let addClientDialogRef = this.dialog.open(AddEditClientSetupComponent, this.dialogOptions);
        addClientDialogRef.componentInstance.heading = 'Add Client';
        addClientDialogRef.componentInstance.saveBtnTitle = 'Add';
    }

    editClientPopup() {
        let editClientDialogRef = this.dialog.open(AddEditClientSetupComponent, this.dialogOptions);
        editClientDialogRef.componentInstance.heading = 'Edit Client';
        editClientDialogRef.componentInstance.saveBtnTitle = 'Save';
        editClientDialogRef.componentInstance.setEditFormValues({
            clientCode: 'Test',
            clientName: 'Test Client',
            address: 'Test',
            city: 'Test',
            state: 'Test',
            zipCode: '422200',
            primaryContact: '(123)-5555-2222',
            phoneNumber: '(123)-5555-2222',
            fax: '7777-5555-2222',
            email: 'test@mail.co'
        });
    }

    deleteClient() {
        let deleteClientSetupAlert = new SweetAlertController();
        deleteClientSetupAlert.deleteConfirm({}, ()=> {
            console.log('yes');
        });
    }

    ngOnDestroy() {
        this.dtCtrl.destroy();
    }  

}