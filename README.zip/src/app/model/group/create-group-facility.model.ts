export class Facility {
      facilityId : string
}